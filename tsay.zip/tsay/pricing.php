<?php
include 'includes/db.php';
$page_title = 'Pricing';

// Fetch all categories with their services
$categories_query = "SELECT * FROM categories ORDER BY display_order ASC";
$categories_result = $conn->query($categories_query);
?>
<?php include 'includes/header.php'; ?>

<section class="services-section">
    <div class="container">
        <div class="section-title">
            <h2>Complete Price List</h2>
            <p>Transparent pricing for all our services</p>
        </div>

        <?php if ($categories_result && $categories_result->num_rows > 0): ?>
            <?php while($category = $categories_result->fetch_assoc()): ?>
                <?php
                // Fetch services for this category
                $services_query = "SELECT * FROM services WHERE category_id = {$category['id']} ORDER BY name ASC";
                $services_result = $conn->query($services_query);
                
                if ($services_result && $services_result->num_rows > 0):
                ?>
                    <div class="pricing-table" data-testid="pricing-category">
                        <h3>
                            <i class="fas <?php echo htmlspecialchars($category['icon']); ?>"></i>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Service</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($service = $services_result->fetch_assoc()): ?>
                                    <tr data-testid="pricing-row">
                                        <td>
                                            <strong><?php echo htmlspecialchars($service['name']); ?></strong>
                                            <?php if ($service['sessions_required']): ?>
                                                <br><small style="color: var(--text-gray); font-style: italic;">
                                                    <?php echo htmlspecialchars($service['sessions_required']); ?>
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['description']); ?></td>
                                        <td>₱<?php echo number_format($service['price'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No pricing information available at the moment.</p>
        <?php endif; ?>

        <!-- Promo Packages Section -->
        <div class="section-title" style="margin-top: 60px;">
            <h2>Special Promo Packages</h2>
            <p>Save more with our bundled offerings</p>
        </div>

        <?php
        $promos_query = "SELECT * FROM promo_packages WHERE is_active = 1 ORDER BY promo_price ASC";
        $promos_result = $conn->query($promos_query);
        ?>

        <div class="promo-grid">
            <?php if ($promos_result && $promos_result->num_rows > 0): ?>
                <?php while($promo = $promos_result->fetch_assoc()): ?>
                    <div class="promo-card" data-testid="promo-package-card">
                        <span class="promo-badge">SPECIAL PACKAGE</span>
                        <h3><?php echo htmlspecialchars($promo['title']); ?></h3>
                        <p><?php echo htmlspecialchars($promo['description']); ?></p>
                        <ul class="services-list">
                            <?php
                            $services = explode(' + ', $promo['services_included']);
                            foreach ($services as $service) {
                                echo '<li>' . htmlspecialchars($service) . '</li>';
                            }
                            ?>
                        </ul>
                        <div class="price-section">
                            <?php if ($promo['original_price']): ?>
                                <span class="original-price">Instead of ₱<?php echo number_format($promo['original_price'], 2); ?></span>
                            <?php endif; ?>
                            <span class="promo-price">₱<?php echo number_format($promo['promo_price'], 2); ?></span>
                        </div>
                        <a href="booking.php" class="btn btn-primary">Book Now</a>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <div style="text-align: center; margin-top: 50px;">
            <a href="booking.php" class="btn btn-primary" data-testid="book-from-pricing-btn">Book Your Appointment</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
