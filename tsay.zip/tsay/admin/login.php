<?php
session_start();
include '../includes/db.php';

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $error_message = 'Please enter both username and password.';
    } else {
        $query = "SELECT * FROM admin_users WHERE username = '$username'";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                header('Location: dashboard.php');
                exit;
            } else {
                $error_message = 'Invalid username or password.';
            }
        } else {
            $error_message = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Tisay Aesthetics</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-login">
        <div class="login-box">
            <div style="text-align: center; margin-bottom: 30px;">
                <!-- Logo Image -->
                <div style="margin-bottom: 20px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="max-width: 200px; height: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                </div>
                
                <!-- Keep the text logo as backup/alternative -->
                <h1 style="font-family: 'Playfair Display', serif; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px;">
                    TISAY AESTHETICS
                </h1>
                <p style="color: var(--text-gray); font-size: 1rem; letter-spacing: 2px; font-weight: 500;">FACIAL · SPMU · LASHES · BROWS</p>
                <p style="color: var(--text-gray); margin-top: 20px; font-size: 0.9rem;">Admin Panel</p>
            </div>

            <?php if ($error_message): ?>
                <div class="error-message" data-testid="admin-login-error"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required data-testid="admin-username-input">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required data-testid="admin-password-input">
                </div>

                <button type="submit" class="btn btn-primary" data-testid="admin-login-btn" style="width: 100%; margin-top: 10px;">
                    <i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i>Login
                </button>
            </form>

            <div style="text-align: center; margin-top: 25px;">
                <p style="color: var(--text-gray); font-size: 0.9rem; margin-bottom: 8px;">
                    <i class="fas fa-info-circle" style="margin-right: 5px;"></i>
                    Default credentials: admin / admin123
                </p>
                <p style="color: var(--text-gray); font-size: 0.9rem; margin: 15px 0;">
                    Don't have an account? 
                    <a href="register.php" style="color: var(--primary-pink); text-decoration: none; font-weight: 600;">
                        <i class="fas fa-user-plus" style="margin-right: 5px;"></i>Create one here
                    </a>
                </p>
                <a href="../index.php" style="color: var(--text-gray); text-decoration: none; font-size: 0.9rem; display: inline-flex; align-items: center;">
                    <i class="fas fa-arrow-left" style="margin-right: 8px;"></i>Back to Website
                </a>
            </div>
        </div>
    </div>
</body>
</html>