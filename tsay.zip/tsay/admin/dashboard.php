<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

include '../includes/db.php';

// Get statistics
$total_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];
$pending_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")->fetch_assoc()['count'];
$total_services = $conn->query("SELECT COUNT(*) as count FROM services")->fetch_assoc()['count'];
$total_inquiries = $conn->query("SELECT COUNT(*) as count FROM contact_inquiries WHERE status = 'new'")->fetch_assoc()['count'];

// Get recent bookings
$recent_bookings = $conn->query("SELECT * FROM bookings ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Tisay Aesthetics</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
                    <div>
                        <h1 style="font-size: 1.4rem; margin-bottom: 5px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">TISAY ADMIN</h1>
                        <p style="font-size: 0.8rem; color: var(--text-gray);">Control Panel</p>
                    </div>
                </div>
            </div>
            <button class="nav-toggle" id="navToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i>Dashboard</a></li>
                <li><a href="manage-bookings.php"><i class="fas fa-calendar-check" style="margin-right: 8px;"></i>Bookings</a></li>
                <li><a href="manage-services.php"><i class="fas fa-spa" style="margin-right: 8px;"></i>Services</a></li>
                <li><a href="manage-promos.php"><i class="fas fa-tag" style="margin-right: 8px;"></i>Promos</a></li>
                <li><a href="logout.php" style="color: var(--primary-pink);"><i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i>Logout</a></li>
            </ul>
            <div class="nav-contact">
                <span style="display: flex; align-items: center; gap: 8px; color: var(--text-dark);">
                    <i class="fas fa-user-circle" style="color: var(--gold);"></i>
                    Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                </span>
            </div>
        </div>
    </nav>

    <section class="admin-dashboard">
        <div class="container">
            <div class="dashboard-header">
                <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 15px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="width: 80px; height: 80px; border-radius: 10px; object-fit: cover; box-shadow: 0 5px 15px rgba(0,0,0,0.2);">
                    <div>
                        <h1>Admin Dashboard</h1>
                        <p>Manage your clinic's website and bookings</p>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 15px; margin-top: 15px;">
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-clock"></i>
                        <span><?php echo date('F d, Y - h:i A'); ?></span>
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-user"></i>
                        <span>Logged in as: <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    </div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card" data-testid="stat-card-bookings">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 50px; height: 50px; background: linear-gradient(135deg, rgba(255, 182, 193, 0.2), rgba(201, 169, 97, 0.2)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-calendar-alt" style="font-size: 1.5rem; color: var(--gold);"></i>
                        </div>
                        <div>
                            <h3><?php echo $total_bookings; ?></h3>
                            <p>Total Bookings</p>
                        </div>
                    </div>
                </div>
                <div class="stat-card" data-testid="stat-card-pending">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 50px; height: 50px; background: linear-gradient(135deg, rgba(255, 182, 193, 0.2), rgba(201, 169, 97, 0.2)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-clock" style="font-size: 1.5rem; color: var(--gold);"></i>
                        </div>
                        <div>
                            <h3><?php echo $pending_bookings; ?></h3>
                            <p>Pending Bookings</p>
                        </div>
                    </div>
                </div>
                <div class="stat-card" data-testid="stat-card-services">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 50px; height: 50px; background: linear-gradient(135deg, rgba(255, 182, 193, 0.2), rgba(201, 169, 97, 0.2)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-spa" style="font-size: 1.5rem; color: var(--gold);"></i>
                        </div>
                        <div>
                            <h3><?php echo $total_services; ?></h3>
                            <p>Total Services</p>
                        </div>
                    </div>
                </div>
                <div class="stat-card" data-testid="stat-card-inquiries">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 50px; height: 50px; background: linear-gradient(135deg, rgba(255, 182, 193, 0.2), rgba(201, 169, 97, 0.2)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-envelope" style="font-size: 1.5rem; color: var(--gold);"></i>
                        </div>
                        <div>
                            <h3><?php echo $total_inquiries; ?></h3>
                            <p>New Inquiries</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="admin-table">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 20px; background: var(--light-gray);">
                    <h2 style="margin: 0;">Recent Bookings</h2>
                    <div style="display: flex; gap: 10px;">
                        <span style="font-size: 0.9rem; color: var(--text-gray); display: flex; align-items: center; gap: 5px;">
                            <i class="fas fa-info-circle"></i>
                            Showing last 10 bookings
                        </span>
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Service</th>
                            <th>Date & Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_bookings && $recent_bookings->num_rows > 0): ?>
                            <?php while($booking = $recent_bookings->fetch_assoc()): ?>
                                <tr data-testid="booking-row">
                                    <td style="font-weight: 600;">#<?php echo $booking['id']; ?></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 8px;">
                                            <i class="fas fa-user" style="color: var(--text-gray);"></i>
                                            <?php echo htmlspecialchars($booking['name']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 8px;">
                                            <i class="fas fa-phone" style="color: var(--text-gray);"></i>
                                            <?php echo htmlspecialchars($booking['phone']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($booking['service']); ?></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 8px;">
                                            <i class="fas fa-calendar" style="color: var(--text-gray);"></i>
                                            <?php echo date('M d, Y', strtotime($booking['preferred_date'])); ?>
                                            <i class="fas fa-clock" style="color: var(--text-gray); margin-left: 8px;"></i>
                                            <?php echo date('g:i A', strtotime($booking['preferred_time'])); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $booking['status']; ?>" data-testid="booking-status">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="manage-bookings.php?id=<?php echo $booking['id']; ?>" class="btn btn-outline btn-small" data-testid="view-booking-btn" style="display: inline-flex; align-items: center; gap: 5px;">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 30px;">
                                    <i class="fas fa-calendar-times" style="font-size: 2rem; color: var(--text-gray); margin-bottom: 10px; display: block;"></i>
                                    No bookings yet
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="text-align: center; margin-top: 30px; padding: 20px; background: var(--light-gray); border-radius: 15px;">
                <h3 style="margin-bottom: 20px; color: var(--text-dark);">Quick Actions</h3>
                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                    <a href="manage-bookings.php" class="btn btn-primary" data-testid="view-all-bookings-btn" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-calendar-check"></i> View All Bookings
                    </a>
                    <a href="manage-services.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-plus-circle"></i> Add New Service
                    </a>
                    <a href="manage-promos.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-tag"></i> Create Promo
                    </a>
                    <a href="../index.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-external-link-alt"></i> View Website
                    </a>
                </div>
            </div>
        </div>
    </section>

    <script src="../js/main.js"></script>
    <script>
        // Add mobile toggle functionality for admin navbar
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', function() {
                    navMenu.classList.toggle('active');
                    // Animate hamburger to X
                    const spans = navToggle.querySelectorAll('span');
                    spans[0].style.transform = navMenu.classList.contains('active') ? 'rotate(45deg) translate(5px, 5px)' : 'none';
                    spans[1].style.opacity = navMenu.classList.contains('active') ? '0' : '1';
                    spans[2].style.transform = navMenu.classList.contains('active') ? 'rotate(-45deg) translate(7px, -6px)' : 'none';
                });
            }
        });
    </script>
</body>
</html>