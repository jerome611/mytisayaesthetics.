<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

include '../includes/db.php';

// Handle service add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_service'])) {
    $service_id = isset($_POST['service_id']) ? intval($_POST['service_id']) : 0;
    $category_id = intval($_POST['category_id']);
    $name = $conn->real_escape_string(trim($_POST['name']));
    $description = $conn->real_escape_string(trim($_POST['description']));
    $price = floatval($_POST['price']);
    $sessions = $conn->real_escape_string(trim($_POST['sessions']));
    
    if ($service_id > 0) {
        // Update
        $query = "UPDATE services SET category_id = $category_id, name = '$name', description = '$description', 
                  price = $price, sessions_required = '$sessions' WHERE id = $service_id";
    } else {
        // Insert
        $query = "INSERT INTO services (category_id, name, description, price, sessions_required) 
                  VALUES ($category_id, '$name', '$description', $price, '$sessions')";
    }
    
    $conn->query($query);
    header('Location: manage-services.php?saved=1');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $service_id = intval($_GET['delete']);
    $conn->query("DELETE FROM services WHERE id = $service_id");
    header('Location: manage-services.php?deleted=1');
    exit;
}

// Get all categories
$categories = $conn->query("SELECT * FROM categories ORDER BY display_order");

// Get all services
$services = $conn->query("SELECT s.*, c.name as category_name FROM services s JOIN categories c ON s.category_id = c.id ORDER BY c.display_order, s.name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
                    <div>
                        <h1 style="font-size: 1.4rem; margin-bottom: 5px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">TISAY ADMIN</h1>
                        <p style="font-size: 0.8rem; color: var(--text-gray);">Services Manager</p>
                    </div>
                </div>
            </div>
            <button class="nav-toggle" id="navToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i>Dashboard</a></li>
                <li><a href="manage-bookings.php"><i class="fas fa-calendar-check" style="margin-right: 8px;"></i>Bookings</a></li>
                <li><a href="manage-services.php" class="active"><i class="fas fa-spa" style="margin-right: 8px;"></i>Services</a></li>
                <li><a href="manage-promos.php"><i class="fas fa-tag" style="margin-right: 8px;"></i>Promos</a></li>
                <li><a href="logout.php" style="color: var(--primary-pink);"><i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i>Logout</a></li>
            </ul>
            <div class="nav-contact">
                <span style="display: flex; align-items: center; gap: 8px; color: var(--text-dark);">
                    <i class="fas fa-user-circle" style="color: var(--gold);"></i>
                    <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                </span>
            </div>
        </div>
    </nav>

    <section class="admin-dashboard">
        <div class="container">
            <div class="dashboard-header">
                <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 15px;">
                    <div style="width: 60px; height: 60px; background: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                        <i class="fas fa-spa" style="font-size: 2rem; color: var(--gold);"></i>
                    </div>
                    <div>
                        <h1>Manage Services</h1>
                        <p>Add, edit, or remove services</p>
                    </div>
                </div>
                <div style="display: flex; gap: 15px; margin-top: 15px; flex-wrap: wrap;">
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-list"></i>
                        <span>Total Services: <?php echo $services->num_rows; ?></span>
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-layer-group"></i>
                        <span>Categories: <?php echo $categories->num_rows; ?></span>
                    </div>
                </div>
            </div>

            <?php if (isset($_GET['saved'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-check-circle"></i>
                    Service saved successfully!
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-trash-alt"></i>
                    Service deleted successfully!
                </div>
            <?php endif; ?>

            <!-- Add New Service Form -->
            <div class="booking-form" style="max-width: 100%; margin-bottom: 40px; border: 2px solid var(--light-gray);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-plus" style="color: white;"></i>
                    </div>
                    <h2>Add New Service</h2>
                </div>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-tag" style="margin-right: 8px;"></i>Category</label>
                            <select name="category_id" required data-testid="service-category-select">
                                <?php 
                                $categories_result = $categories;
                                $categories->data_seek(0);
                                while($cat = $categories->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-pen" style="margin-right: 8px;"></i>Service Name</label>
                            <input type="text" name="name" required data-testid="service-name-input" placeholder="e.g., Basic Facial with PDT">
                        </div>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-align-left" style="margin-right: 8px;"></i>Description</label>
                        <input type="text" name="description" required data-testid="service-description-input" placeholder="e.g., Deep cleansing facial with Photo Dynamic Therapy">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-tag" style="margin-right: 8px;"></i>Price (₱)</label>
                            <input type="number" step="0.01" name="price" required data-testid="service-price-input" placeholder="e.g., 499.00">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-clock" style="margin-right: 8px;"></i>Sessions Required (Optional)</label>
                            <input type="text" name="sessions" placeholder="e.g., Minimum 8 sessions" data-testid="service-sessions-input">
                        </div>
                    </div>
                    <button type="submit" name="save_service" class="btn btn-primary" data-testid="save-service-btn" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-save"></i> Add Service
                    </button>
                </form>
            </div>

            <!-- Services List -->
            <div class="admin-table">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 20px; background: var(--light-gray);">
                    <h2 style="margin: 0;">All Services</h2>
                    <div style="display: flex; gap: 10px;">
                        <span style="font-size: 0.9rem; color: var(--text-gray); display: flex; align-items: center; gap: 5px;">
                            <i class="fas fa-filter"></i>
                            Grouped by Category
                        </span>
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Service Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Sessions</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($services && $services->num_rows > 0):
                            $current_category = '';
                            while($service = $services->fetch_assoc()): 
                            if ($current_category !== $service['category_name']):
                                $current_category = $service['category_name'];
                        ?>
                            <tr style="background: var(--light-gray);">
                                <td colspan="7" style="font-weight: 600; color: var(--text-dark); padding: 10px 20px;">
                                    <i class="fas fa-folder" style="margin-right: 10px; color: var(--gold);"></i>
                                    <?php echo htmlspecialchars($current_category); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                            <tr data-testid="service-row">
                                <td style="font-weight: 600;">#<?php echo $service['id']; ?></td>
                                <td>
                                    <span style="background: rgba(255, 182, 193, 0.1); padding: 3px 10px; border-radius: 15px; font-size: 0.85rem;">
                                        <?php echo htmlspecialchars($service['category_name']); ?>
                                    </span>
                                </td>
                                <td><strong><?php echo htmlspecialchars($service['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($service['description']); ?></td>
                                <td><strong style="color: var(--gold);">₱<?php echo number_format($service['price'], 2); ?></strong></td>
                                <td><small style="color: var(--text-gray);"><?php echo htmlspecialchars($service['sessions_required'] ?: 'Single session'); ?></small></td>
                                <td>
                                    <a href="?delete=<?php echo $service['id']; ?>" 
                                       onclick="return confirm('Are you sure? This action cannot be undone.')" 
                                       class="btn btn-outline btn-small"
                                       data-testid="delete-service-btn"
                                       style="background: #f8d7da; border-color: #f5c6cb; color: #721c24; display: inline-flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        <?php 
                            endwhile;
                        else: 
                        ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 30px;">
                                    <i class="fas fa-spa" style="font-size: 2rem; color: var(--text-gray); margin-bottom: 10px; display: block;"></i>
                                    No services found. Add your first service above.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="text-align: center; margin-top: 30px;">
                <a href="dashboard.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </section>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', function() {
                    navMenu.classList.toggle('active');
                    // Animate hamburger to X
                    const spans = navToggle.querySelectorAll('span');
                    spans[0].style.transform = navMenu.classList.contains('active') ? 'rotate(45deg) translate(5px, 5px)' : 'none';
                    spans[1].style.opacity = navMenu.classList.contains('active') ? '0' : '1';
                    spans[2].style.transform = navMenu.classList.contains('active') ? 'rotate(-45deg) translate(7px, -6px)' : 'none';
                });
            }
        });
    </script>
</body>
</html>