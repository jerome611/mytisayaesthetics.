<?php
session_start();
include '../includes/db.php';

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $email = $conn->real_escape_string(trim($_POST['email']));

    // Validation
    if (empty($username) || empty($password) || empty($confirm_password) || empty($email)) {
        $error_message = 'All fields are required.';
    } elseif ($password !== $confirm_password) {
        $error_message = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error_message = 'Password must be at least 6 characters long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        // Check if username already exists
        $check_query = "SELECT id FROM admin_users WHERE username = '$username' OR email = '$email'";
        $check_result = $conn->query($check_query);

        if ($check_result && $check_result->num_rows > 0) {
            $error_message = 'Username or email already exists.';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new admin user
            $insert_query = "INSERT INTO admin_users (username, password, email, created_at) 
                            VALUES ('$username', '$hashed_password', '$email', NOW())";
            
            if ($conn->query($insert_query)) {
                $success_message = 'Account created successfully! You can now login.';
                // Clear form
                $username = $email = '';
            } else {
                $error_message = 'Error creating account. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration - Tisay Aesthetics</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-login">
        <div class="register-box">
            <div style="text-align: center; margin-bottom: 30px;">
                <!-- Logo Image -->
                <div style="margin-bottom: 20px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="max-width: 200px; height: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                </div>
                
                <h1 style="font-family: 'Playfair Display', serif; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px;">
                    TISAY AESTHETICS
                </h1>
                <p style="color: var(--text-gray); font-size: 1rem; letter-spacing: 2px; font-weight: 500;">FACIAL · SPMU · LASHES · BROWS</p>
                <p style="color: var(--text-gray); margin-top: 20px; font-size: 0.9rem;">Admin Registration</p>
            </div>

            <?php if ($success_message): ?>
                <div class="success-message" data-testid="admin-register-success">
                    <i class="fas fa-check-circle" style="margin-right: 8px;"></i><?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="error-message" data-testid="admin-register-error">
                    <i class="fas fa-exclamation-circle" style="margin-right: 8px;"></i><?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user" style="margin-right: 8px;"></i>Username
                    </label>
                    <input type="text" id="username" name="username" required 
                           value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>"
                           data-testid="admin-register-username-input"
                           placeholder="Enter your username">
                </div>

                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope" style="margin-right: 8px;"></i>Email
                    </label>
                    <input type="email" id="email" name="email" required 
                           value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"
                           data-testid="admin-register-email-input"
                           placeholder="Enter your email address">
                </div>

                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock" style="margin-right: 8px;"></i>Password
                    </label>
                    <input type="password" id="password" name="password" required 
                           minlength="6" data-testid="admin-register-password-input"
                           placeholder="Enter your password">
                    <small style="color: var(--text-gray); font-size: 0.8rem;">
                        <i class="fas fa-info-circle" style="margin-right: 5px;"></i>Minimum 6 characters
                    </small>
                </div>

                <div class="form-group">
                    <label for="confirm_password">
                        <i class="fas fa-lock" style="margin-right: 8px;"></i>Confirm Password
                    </label>
                    <input type="password" id="confirm_password" name="confirm_password" required 
                           data-testid="admin-register-confirm-password-input"
                           placeholder="Confirm your password">
                </div>

                <button type="submit" class="btn btn-primary" data-testid="admin-register-btn" style="width: 100%; margin-top: 10px;">
                    <i class="fas fa-user-plus" style="margin-right: 8px;"></i>Create Account
                </button>
            </form>

            <div style="text-align: center; margin-top: 25px;">
                <p style="color: var(--text-gray); font-size: 0.9rem;">
                    Already have an account? 
                    <a href="login.php" style="color: var(--primary-pink); text-decoration: none; font-weight: 600;">
                        <i class="fas fa-sign-in-alt" style="margin-right: 5px;"></i>Login here
                    </a>
                </p>
                <a href="../index.php" style="color: var(--text-gray); text-decoration: none; font-size: 0.9rem; display: inline-flex; align-items: center; margin-top: 10px;">
                    <i class="fas fa-arrow-left" style="margin-right: 8px;"></i>Back to Website
                </a>
            </div>
        </div>
    </div>
</body>
</html>