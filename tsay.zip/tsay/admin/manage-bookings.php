<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

include '../includes/db.php';

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $booking_id = intval($_POST['booking_id']);
    $new_status = $conn->real_escape_string($_POST['status']);
    
    $update_query = "UPDATE bookings SET status = '$new_status' WHERE id = $booking_id";
    $conn->query($update_query);
    
    header('Location: manage-bookings.php?updated=1');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $booking_id = intval($_GET['delete']);
    $conn->query("DELETE FROM bookings WHERE id = $booking_id");
    header('Location: manage-bookings.php?deleted=1');
    exit;
}

// Get all bookings
$bookings = $conn->query("SELECT * FROM bookings ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
                    <div>
                        <h1 style="font-size: 1.4rem; margin-bottom: 5px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">TISAY ADMIN</h1>
                        <p style="font-size: 0.8rem; color: var(--text-gray);">Bookings Manager</p>
                    </div>
                </div>
            </div>
            <button class="nav-toggle" id="navToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i>Dashboard</a></li>
                <li><a href="manage-bookings.php" class="active"><i class="fas fa-calendar-check" style="margin-right: 8px;"></i>Bookings</a></li>
                <li><a href="manage-services.php"><i class="fas fa-spa" style="margin-right: 8px;"></i>Services</a></li>
                <li><a href="manage-promos.php"><i class="fas fa-tag" style="margin-right: 8px;"></i>Promos</a></li>
                <li><a href="logout.php" style="color: var(--primary-pink);"><i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i>Logout</a></li>
            </ul>
            <div class="nav-contact">
                <span style="display: flex; align-items: center; gap: 8px; color: var(--text-dark);">
                    <i class="fas fa-user-circle" style="color: var(--gold);"></i>
                    <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                </span>
            </div>
        </div>
    </nav>

    <section class="admin-dashboard">
        <div class="container">
            <div class="dashboard-header">
                <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 15px;">
                    <div style="width: 60px; height: 60px; background: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                        <i class="fas fa-calendar-alt" style="font-size: 2rem; color: var(--gold);"></i>
                    </div>
                    <div>
                        <h1>Manage Bookings</h1>
                        <p>View and update booking status</p>
                    </div>
                </div>
                <div style="display: flex; gap: 15px; margin-top: 15px; flex-wrap: wrap;">
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-list"></i>
                        <span>Total Bookings: <?php echo $bookings->num_rows; ?></span>
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-clock"></i>
                        <span>Last Updated: <?php echo date('h:i A'); ?></span>
                    </div>
                </div>
            </div>

            <?php if (isset($_GET['updated'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-check-circle"></i>
                    Booking status updated successfully!
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-trash-alt"></i>
                    Booking deleted successfully!
                </div>
            <?php endif; ?>

            <div class="admin-table">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 20px; background: var(--light-gray);">
                    <h2 style="margin: 0;">All Bookings</h2>
                    <div style="display: flex; gap: 10px;">
                        <span style="font-size: 0.9rem; color: var(--text-gray); display: flex; align-items: center; gap: 5px;">
                            <i class="fas fa-sort"></i>
                            Sorted by: Most Recent
                        </span>
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Service</th>
                            <th>Appointment</th>
                            <th>Status</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($bookings && $bookings->num_rows > 0): ?>
                            <?php while($booking = $bookings->fetch_assoc()): ?>
                                <tr data-testid="manage-booking-row">
                                    <td style="font-weight: 600;">#<?php echo $booking['id']; ?></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 8px;">
                                            <i class="fas fa-user" style="color: var(--text-gray);"></i>
                                            <?php echo htmlspecialchars($booking['name']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="margin-bottom: 5px;">
                                            <i class="fas fa-phone" style="color: var(--text-gray); margin-right: 8px;"></i>
                                            <?php echo htmlspecialchars($booking['phone']); ?>
                                        </div>
                                        <div>
                                            <i class="fas fa-envelope" style="color: var(--text-gray); margin-right: 8px;"></i>
                                            <small><?php echo htmlspecialchars($booking['email']); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($booking['service']); ?></td>
                                    <td>
                                        <div style="margin-bottom: 5px;">
                                            <i class="fas fa-calendar" style="color: var(--text-gray); margin-right: 8px;"></i>
                                            <?php echo date('M d, Y', strtotime($booking['preferred_date'])); ?>
                                        </div>
                                        <div>
                                            <i class="fas fa-clock" style="color: var(--text-gray); margin-right: 8px;"></i>
                                            <?php echo date('g:i A', strtotime($booking['preferred_time'])); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <form method="POST" style="margin: 0;">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                            <select name="status" class="badge badge-<?php echo $booking['status']; ?>" onchange="this.form.submit()" data-testid="status-select" style="cursor: pointer; padding: 5px 10px; border: none; border-radius: 15px; font-size: 0.85rem; font-weight: 600;">
                                                <option value="pending" <?php echo $booking['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="confirmed" <?php echo $booking['status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                                <option value="completed" <?php echo $booking['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                <option value="cancelled" <?php echo $booking['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                            </select>
                                            <input type="hidden" name="update_status" value="1">
                                        </form>
                                    </td>
                                    <td>
                                        <small style="color: var(--text-gray);">
                                            <?php echo htmlspecialchars($booking['notes'] ?: 'No notes'); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <a href="?delete=<?php echo $booking['id']; ?>" 
                                           onclick="return confirm('Are you sure you want to delete this booking?')" 
                                           class="btn btn-outline btn-small"
                                           data-testid="delete-booking-btn"
                                           style="background: #f8d7da; border-color: #f5c6cb; color: #721c24; display: inline-flex; align-items: center; gap: 5px;">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 30px;">
                                    <i class="fas fa-calendar-times" style="font-size: 2rem; color: var(--text-gray); margin-bottom: 10px; display: block;"></i>
                                    No bookings found
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="text-align: center; margin-top: 30px;">
                <a href="dashboard.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </section>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', function() {
                    navMenu.classList.toggle('active');
                    // Animate hamburger to X
                    const spans = navToggle.querySelectorAll('span');
                    spans[0].style.transform = navMenu.classList.contains('active') ? 'rotate(45deg) translate(5px, 5px)' : 'none';
                    spans[1].style.opacity = navMenu.classList.contains('active') ? '0' : '1';
                    spans[2].style.transform = navMenu.classList.contains('active') ? 'rotate(-45deg) translate(7px, -6px)' : 'none';
                });
            }
        });
    </script>
</body>
</html>