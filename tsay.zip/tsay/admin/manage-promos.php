<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

include '../includes/db.php';

// Handle promo add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_promo'])) {
    $promo_id = isset($_POST['promo_id']) ? intval($_POST['promo_id']) : 0;
    $title = $conn->real_escape_string(trim($_POST['title']));
    $description = $conn->real_escape_string(trim($_POST['description']));
    $services_included = $conn->real_escape_string(trim($_POST['services_included']));
    $original_price = floatval($_POST['original_price']);
    $promo_price = floatval($_POST['promo_price']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    if ($promo_id > 0) {
        // Update
        $query = "UPDATE promo_packages SET title = '$title', description = '$description', 
                  services_included = '$services_included', original_price = $original_price, 
                  promo_price = $promo_price, is_active = $is_active WHERE id = $promo_id";
    } else {
        // Insert
        $query = "INSERT INTO promo_packages (title, description, services_included, original_price, promo_price, is_active) 
                  VALUES ('$title', '$description', '$services_included', $original_price, $promo_price, $is_active)";
    }
    
    $conn->query($query);
    header('Location: manage-promos.php?saved=1');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $promo_id = intval($_GET['delete']);
    $conn->query("DELETE FROM promo_packages WHERE id = $promo_id");
    header('Location: manage-promos.php?deleted=1');
    exit;
}

// Get all promos
$promos = $conn->query("SELECT * FROM promo_packages ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Promos - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <img src="../images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                         alt="Tisay Aesthetics Logo" 
                         style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
                    <div>
                        <h1 style="font-size: 1.4rem; margin-bottom: 5px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">TISAY ADMIN</h1>
                        <p style="font-size: 0.8rem; color: var(--text-gray);">Promos Manager</p>
                    </div>
                </div>
            </div>
            <button class="nav-toggle" id="navToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="nav-menu" id="navMenu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i>Dashboard</a></li>
                <li><a href="manage-bookings.php"><i class="fas fa-calendar-check" style="margin-right: 8px;"></i>Bookings</a></li>
                <li><a href="manage-services.php"><i class="fas fa-spa" style="margin-right: 8px;"></i>Services</a></li>
                <li><a href="manage-promos.php" class="active"><i class="fas fa-tag" style="margin-right: 8px;"></i>Promos</a></li>
                <li><a href="logout.php" style="color: var(--primary-pink);"><i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i>Logout</a></li>
            </ul>
            <div class="nav-contact">
                <span style="display: flex; align-items: center; gap: 8px; color: var(--text-dark);">
                    <i class="fas fa-user-circle" style="color: var(--gold);"></i>
                    <?php echo htmlspecialchars($_SESSION['admin_username']); ?>
                </span>
            </div>
        </div>
    </nav>

    <section class="admin-dashboard">
        <div class="container">
            <div class="dashboard-header">
                <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 15px;">
                    <div style="width: 60px; height: 60px; background: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                        <i class="fas fa-tag" style="font-size: 2rem; color: var(--gold);"></i>
                    </div>
                    <div>
                        <h1>Manage Promo Packages</h1>
                        <p>Create and manage special offers</p>
                    </div>
                </div>
                <div style="display: flex; gap: 15px; margin-top: 15px; flex-wrap: wrap;">
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-tags"></i>
                        <span>Total Promos: <?php echo $promos->num_rows; ?></span>
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-percentage"></i>
                        <span>Average Discount: 30-50%</span>
                    </div>
                </div>
            </div>

            <?php if (isset($_GET['saved'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-check-circle"></i>
                    Promo saved successfully!
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="success-message" style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-trash-alt"></i>
                    Promo deleted successfully!
                </div>
            <?php endif; ?>

            <!-- Add New Promo Form -->
            <div class="booking-form" style="max-width: 100%; margin-bottom: 40px; border: 2px solid var(--light-gray);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary-pink), var(--gold)); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-plus" style="color: white;"></i>
                    </div>
                    <h2>Add New Promo Package</h2>
                </div>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-heading" style="margin-right: 8px;"></i>Package Title</label>
                        <input type="text" name="title" required data-testid="promo-title-input" placeholder="e.g., Ultimate Beauty Package">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-align-left" style="margin-right: 8px;"></i>Description</label>
                        <input type="text" name="description" required data-testid="promo-description-input" placeholder="e.g., Complete transformation package">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-list-check" style="margin-right: 8px;"></i>Services Included (separate with ' + ')</label>
                        <textarea name="services_included" required data-testid="promo-services-textarea" placeholder="e.g., Basic Facial with PDT + Classic Lash Extensions + Manicure & Pedicure" rows="3"></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-money-bill-wave" style="margin-right: 8px;"></i>Original Price (₱)</label>
                            <input type="number" step="0.01" name="original_price" data-testid="promo-original-price-input" placeholder="e.g., 1898.00">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag" style="margin-right: 8px;"></i>Promo Price (₱)</label>
                            <input type="number" step="0.01" name="promo_price" required data-testid="promo-price-input" placeholder="e.g., 999.00">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" name="is_active" checked data-testid="promo-active-checkbox" style="width: 20px; height: 20px;">
                            <span style="display: flex; align-items: center; gap: 5px;">
                                <i class="fas fa-eye"></i> Active (Show on website)
                            </span>
                        </label>
                    </div>
                    <button type="submit" name="save_promo" class="btn btn-primary" data-testid="save-promo-btn" style="display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-save"></i> Add Promo Package
                    </button>
                </form>
            </div>

            <!-- Promos List -->
            <div class="admin-table">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 20px; background: var(--light-gray);">
                    <h2 style="margin: 0;">All Promo Packages</h2>
                    <div style="display: flex; gap: 10px;">
                        <span style="font-size: 0.9rem; color: var(--text-gray); display: flex; align-items: center; gap: 5px;">
                            <i class="fas fa-sort"></i>
                            Sorted by: Most Recent
                        </span>
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Services</th>
                            <th>Original Price</th>
                            <th>Promo Price</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($promos && $promos->num_rows > 0):
                            while($promo = $promos->fetch_assoc()): 
                        ?>
                            <tr data-testid="promo-row" style="<?php echo !$promo['is_active'] ? 'opacity: 0.7;' : ''; ?>">
                                <td style="font-weight: 600;">#<?php echo $promo['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($promo['title']); ?></strong><br>
                                    <small style="color: var(--text-gray);"><?php echo htmlspecialchars($promo['description']); ?></small>
                                </td>
                                <td>
                                    <div style="font-size: 0.9rem;">
                                        <?php 
                                        $services = explode(' + ', $promo['services_included']);
                                        foreach ($services as $service) {
                                            echo '<div style="display: flex; align-items: center; gap: 5px; margin-bottom: 3px;">
                                                    <i class="fas fa-check" style="color: var(--gold); font-size: 0.8rem;"></i>
                                                    <span>' . htmlspecialchars(trim($service)) . '</span>
                                                  </div>';
                                        }
                                        ?>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($promo['original_price'] > 0): ?>
                                        <span style="text-decoration: line-through; color: var(--text-gray);">₱<?php echo number_format($promo['original_price'], 2); ?></span>
                                    <?php else: ?>
                                        <span style="color: var(--text-gray);">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong style="color: var(--gold); font-size: 1.2rem;">₱<?php echo number_format($promo['promo_price'], 2); ?></strong>
                                    <?php if ($promo['original_price'] > 0): 
                                        $discount = (($promo['original_price'] - $promo['promo_price']) / $promo['original_price']) * 100;
                                    ?>
                                        <div style="background: var(--primary-pink); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem; margin-top: 5px; display: inline-block;">
                                            Save <?php echo round($discount); ?>%
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo $promo['is_active'] ? 'badge-confirmed' : 'badge-cancelled'; ?>" data-testid="promo-status" style="display: inline-flex; align-items: center; gap: 5px;">
                                        <?php if ($promo['is_active']): ?>
                                            <i class="fas fa-check-circle"></i> Active
                                        <?php else: ?>
                                            <i class="fas fa-times-circle"></i> Inactive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="?delete=<?php echo $promo['id']; ?>" 
                                       onclick="return confirm('Are you sure? This will permanently delete this promo.')" 
                                       class="btn btn-outline btn-small"
                                       data-testid="delete-promo-btn"
                                       style="background: #f8d7da; border-color: #f5c6cb; color: #721c24; display: inline-flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        <?php 
                            endwhile;
                        else: 
                        ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 30px;">
                                    <i class="fas fa-tags" style="font-size: 2rem; color: var(--text-gray); margin-bottom: 10px; display: block;"></i>
                                    No promo packages found. Create your first promo above.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="text-align: center; margin-top: 30px;">
                <a href="dashboard.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </section>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', function() {
                    navMenu.classList.toggle('active');
                    // Animate hamburger to X
                    const spans = navToggle.querySelectorAll('span');
                    spans[0].style.transform = navMenu.classList.contains('active') ? 'rotate(45deg) translate(5px, 5px)' : 'none';
                    spans[1].style.opacity = navMenu.classList.contains('active') ? '0' : '1';
                    spans[2].style.transform = navMenu.classList.contains('active') ? 'rotate(-45deg) translate(7px, -6px)' : 'none';
                });
            }
        });
    </script>
</body>
</html>s