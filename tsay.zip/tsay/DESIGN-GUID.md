"# TISAY AESTHETICS - DESIGN & VISUAL GUIDE

## COLOR PALETTE

### Primary Colors
```
Light Pink:     #FFB6C1 (rgb(255, 182, 193))
Soft Pink:      #FFC0CB (rgb(255, 192, 203))
Gold:           #C9A961 (rgb(201, 169, 97))
Dark Gold:      #B8934A (rgb(184, 147, 74))
```

### Neutral Colors
```
White:          #FFFFFF
Light Gray:     #F8F9FA
Text Dark:      #2C2C2C
Text Gray:      #666666
```

### Usage
- **Primary Pink**: Main accent color, buttons, links, highlights
- **Gold**: Secondary accent, prices, premium features
- **White**: Backgrounds, clean spaces
- **Light Gray**: Section backgrounds, subtle separators
- **Text Dark**: Main body text, headings
- **Text Gray**: Secondary text, descriptions

## TYPOGRAPHY

### Font Families
- **Headings**: 'Playfair Display', serif
  - Elegant, luxurious, professional
  - Used for: h1, h2, h3, h4, h5, h6, brand name
  
- **Body Text**: 'Inter', sans-serif
  - Clean, readable, modern
  - Used for: paragraphs, buttons, forms, navigation

### Font Sizes
```
Hero Heading (h1):        3.5rem (56px) desktop | 2.5rem (40px) mobile
Section Headings (h2):    2.5rem (40px) desktop | 2rem (32px) mobile
Card Headings (h3):       1.8rem (28.8px)
Body Text:                1rem (16px)
Small Text:               0.9rem (14.4px)
```

### Font Weights
- Light: 300
- Regular: 400
- Medium: 500
- Semi-bold: 600
- Bold: 700

## LAYOUT STRUCTURE

### Homepage Wireframe
```
+----------------------------------------------------------+
|  NAVBAR                                                   |
|  [TISAY AESTHETICS]  [Home] [Services] [Pricing] [Book]  |
|                                      [Phone] [Facebook]   |
+----------------------------------------------------------+
|                                                           |
|                    HERO SECTION                          |
|              TISAY AESTHETICS (large)                    |
|     Experience a true beauty transformation...           |
|                  [BOOK NOW BUTTON]                       |
|                                                           |
+----------------------------------------------------------+
|              SPECIAL PROMO PACKAGES                      |
|   +---------------+  +---------------+  +---------------+|
|   | LIMITED OFFER |  | LIMITED OFFER |  | LIMITED OFFER ||
|   | Package Title |  | Package Title |  | Package Title ||
|   | Description   |  | Description   |  | Description   ||
|   | • Service 1   |  | • Service 1   |  | • Service 1   ||
|   | • Service 2   |  | • Service 2   |  | • Service 2   ||
|   | ₱999  ₱1,898  |  | ₱599  ₱1,548  |  | ₱1,299 ₱2,097 ||
|   | [Book Package]|  | [Book Package]|  | [Book Package]||
|   +---------------+  +---------------+  +---------------+|
+----------------------------------------------------------+
|                   OUR SERVICES                           |
|  +------------+  +------------+  +------------+          |
|  |   ICON     |  |   ICON     |  |   ICON     |          |
|  |  Facials   |  |  Lashes    |  |   Nails    |          |
|  | Description|  | Description|  | Description|          |
|  |[View Details]|[View Details]|[View Details]          |
|  +------------+  +------------+  +------------+          |
|  (8 categories total, 4 per row on desktop)              |
+----------------------------------------------------------+
|                    FOOTER                                |
|  [About] [Contact] [Hours] [Social Links]               |
|  © 2024 Tisay Aesthetics. All rights reserved.          |
+----------------------------------------------------------+
```

### Service Detail Page Wireframe
```
+----------------------------------------------------------+
|  NAVBAR (same as homepage)                               |
+----------------------------------------------------------+
|                                                           |
|           CATEGORY NAME (centered)                       |
|              Category Description                        |
|                                                           |
+----------------------------------------------------------+
|  +-----------------+  +-----------------+                |
|  | Service Name    |  | Service Name    |                |
|  | Description     |  | Description     |                |
|  | ₱599.00        |  | ₱799.00        |                |
|  | Min 8 sessions  |  |                 |                |
|  +-----------------+  +-----------------+                |
|  (Grid of services, 3 per row)                           |
+----------------------------------------------------------+
|        [BOOK NOW]  [Back to Services]                    |
+----------------------------------------------------------+
|  FOOTER                                                   |
+----------------------------------------------------------+
```

### Booking Form Wireframe
```
+----------------------------------------------------------+
|  NAVBAR                                                   |
+----------------------------------------------------------+
|              BOOK YOUR APPOINTMENT                       |
|         Fill out the form below...                       |
|                                                           |
|  +--------------------------------------------------+    |
|  | Full Name *        | Phone Number *              |    |
|  | [____________]     | [____________]              |    |
|  +--------------------------------------------------+    |
|  | Email Address (Optional)                          |    |
|  | [_______________________________________]         |    |
|  +--------------------------------------------------+    |
|  | Desired Service *                                 |    |
|  | [Dropdown: Promo Packages, All Services]          |    |
|  +--------------------------------------------------+    |
|  | Preferred Date *   | Preferred Time *             |    |
|  | [____________]     | [Dropdown: 9AM-5PM]          |    |
|  +--------------------------------------------------+    |
|  | Additional Notes (Optional)                       |    |
|  | [_______________________________________]         |    |
|  | [_______________________________________]         |    |
|  +--------------------------------------------------+    |
|  |          [SUBMIT BOOKING - Full Width]            |    |
|  +--------------------------------------------------+    |
|                                                           |
|  Business Hours: Everyday, 9:00 AM - 5:00 PM            |
|  Contact: 09153206502                                    |
+----------------------------------------------------------+
```

### Admin Dashboard Wireframe
```
+----------------------------------------------------------+
|  ADMIN NAVBAR                                             |
|  [TISAY ADMIN] [Dashboard] [Bookings] [Services] [Logout]|
+----------------------------------------------------------+
|              ADMIN DASHBOARD                             |
|        Manage your clinic's website                      |
|                                                           |
|  +--------+  +--------+  +--------+  +--------+          |
|  |   42   |  |   12   |  |   67   |  |    5   |          |
|  | Total  |  |Pending |  |Services|  |  New   |          |
|  |Bookings|  |Bookings|  |        |  |Messages|          |
|  +--------+  +--------+  +--------+  +--------+          |
|                                                           |
|              RECENT BOOKINGS                             |
|  +--------------------------------------------------+    |
|  | ID | Name  | Phone | Service | Date | Status    |    |
|  |----|-------|-------|---------|------|-----------|    |
|  | #1 | John  | 0915..| Facial  |May 15|[Pending ▼]|    |
|  | #2 | Maria | 0917..| Lashes  |May 16|[Confirmed]|    |
|  +--------------------------------------------------+    |
|                                                           |
|    [View All Bookings]  [View Website]                   |
+----------------------------------------------------------+
```

## DESIGN ELEMENTS

### Buttons

#### Primary Button (Pink Gradient)
```
Background: Linear gradient (135deg, #FFB6C1, #C9A961)
Color: White
Padding: 15px 40px
Border-radius: 50px (pill-shaped)
Box-shadow: 0 10px 30px rgba(255, 182, 193, 0.4)
Hover: Lift up 3px with stronger shadow
```

#### Outline Button
```
Background: Transparent
Border: 2px solid #FFB6C1
Color: Dark text
Hover: Fill with pink background
```

### Cards

#### Promo Card
```
Background: White
Padding: 40px
Border-radius: 20px
Box-shadow: 0 10px 40px rgba(0,0,0,0.08)
Top border: 5px gradient bar
Hover: Lift up 10px
Badge: \"LIMITED OFFER\" in pink gradient
```

#### Service Card
```
Background: White
Padding: 35px
Border-radius: 20px
Text-align: center
Icon: 80px circle with gradient background
Hover: Pink border appears + lift up
```

### Navigation

#### Desktop Navigation
```
Sticky top navbar
Background: White with blur effect (backdrop-filter)
Logo: Gradient text (pink to gold)
Links: Horizontal list
Active link: Pink color + gold underline
```

#### Mobile Navigation
```
Hamburger menu icon (3 lines)
Slide-in menu from left
Vertical link list
Full-width mobile-friendly
```

### Forms

#### Input Fields
```
Border: 2px solid #e0e0e0
Border-radius: 10px
Padding: 12px 15px
Focus: Pink border (#FFB6C1)
Font: Inter, 1rem
```

#### Success Message
```
Background: Light green (#d4edda)
Border: Green (#c3e6cb)
Color: Dark green (#155724)
Border-radius: 10px
```

#### Error Message
```
Background: Light red (#f8d7da)
Border: Red (#f5c6cb)
Color: Dark red (#721c24)
Border-radius: 10px
```

## RESPONSIVE BREAKPOINTS

```css
Desktop:  1200px and above (default)
Tablet:   768px to 1199px
Mobile:   Below 768px

Changes on Mobile:
- Single column layout
- Larger touch targets
- Hamburger menu
- Stacked form fields
- Smaller font sizes
- Full-width buttons
```

## SPACING SYSTEM

```
Extra Small:  5px
Small:        10px
Medium:       20px
Large:        30px
Extra Large:  40px
Section:      80px (top and bottom padding)
Container:    Max-width 1200px, centered
```

## ICON USAGE

### Service Category Icons (Font Awesome)
- Facials: fa-spa
- Lashes & Brows: fa-eye
- Nails: fa-hand-sparkles
- Hair Removal: fa-leaf
- Slimming: fa-heartbeat
- SPMU: fa-palette
- Advanced: fa-star
- Massage: fa-hands

### Contact Icons
- Phone: fa-phone
- Facebook: fab fa-facebook
- Clock: fa-clock
- Location: fa-map-marker-alt

## ANIMATION & TRANSITIONS

### Hover Effects
```css
Button hover: 0.3s ease (lift + shadow)
Card hover: 0.3s ease (lift + border)
Link hover: 0.3s ease (color change)
```

### Page Load
```
Smooth fade-in for content
Scroll animations (optional enhancement)
```

## ACCESSIBILITY

- High contrast text (WCAG AA compliant)
- Focus states on all interactive elements
- Alt text for images (when added)
- Semantic HTML structure
- Form labels properly associated
- Keyboard navigation support

## BRAND VOICE & TONE

**Keywords:**
- Affordable
- Quality
- Professional
- Beautiful
- Transformative
- Welcoming
- Trustworthy

**Writing Style:**
- Clear and direct
- Warm and friendly
- Professional but approachable
- Benefit-focused
- Action-oriented CTAs

## IMAGE GUIDELINES

### Photo Style
- Well-lit, professional photography
- Clean, minimal backgrounds
- Focus on results and happy clients
- Warm color tones
- High resolution (minimum 1200px width)

### Placement
- Hero: Large background or featured image
- Services: Icons or representative photos
- About: Staff and clinic photos
- Testimonials: Customer photos (with permission)

## MOOD & FEEL

**Overall Aesthetic:**
- Elegant yet accessible
- Feminine without being childish
- Professional without being cold
- Modern and fresh
- Clean and organized
- Trustworthy and established

**Emotional Response Goals:**
- Feel confident booking an appointment
- Trust in the quality of services
- Excitement about transformation
- Comfort and relaxation
- Value for money

---

**Design Credits:**
Color Scheme: Soft Pink + White + Gold (Professional Beauty Aesthetic)
Typography: Playfair Display + Inter (Elegant + Modern)
Style: Clean, professional, responsive, user-friendly

**This design creates a perfect balance between luxury and affordability, exactly matching Tisay Aesthetics' brand promise.**
"