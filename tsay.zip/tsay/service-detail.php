<?php
include 'includes/db.php';

// Get category ID from URL
$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($category_id === 0) {
    header('Location: services.php');
    exit;
}

// Fetch category details
$category_query = "SELECT * FROM categories WHERE id = $category_id";
$category_result = $conn->query($category_query);

if (!$category_result || $category_result->num_rows === 0) {
    header('Location: services.php');
    exit;
}

$category = $category_result->fetch_assoc();
$page_title = $category['name'];

// Fetch all services in this category
$services_query = "SELECT * FROM services WHERE category_id = $category_id ORDER BY name ASC";
$services_result = $conn->query($services_query);
?>
<?php include 'includes/header.php'; ?>

<section class="service-detail">
    <div class="container">
        <div class="detail-header">
            <h1><?php echo htmlspecialchars($category['name']); ?></h1>
            <p><?php echo htmlspecialchars($category['description']); ?></p>
        </div>

        <div class="service-items">
            <?php if ($services_result && $services_result->num_rows > 0): ?>
                <?php while($service = $services_result->fetch_assoc()): ?>
                    <div class="service-item" data-testid="service-item">
                        <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                        <p><?php echo htmlspecialchars($service['description']); ?></p>
                        <div class="price">₱<?php echo number_format($service['price'], 2); ?></div>
                        <?php if ($service['sessions_required']): ?>
                            <div class="sessions"><?php echo htmlspecialchars($service['sessions_required']); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No services available in this category yet.</p>
            <?php endif; ?>
        </div>

        <div style="text-align: center; margin-top: 50px;">
            <a href="booking.php" class="btn btn-primary" data-testid="book-service-btn">Book Now</a>
            <a href="services.php" class="btn btn-outline" style="margin-left: 15px;">Back to Services</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
