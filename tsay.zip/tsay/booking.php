<?php
include 'includes/db.php';
$page_title = 'Book Appointment';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $service = $conn->real_escape_string(trim($_POST['service']));
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);
    $notes = $conn->real_escape_string(trim($_POST['notes']));

    if (empty($name) || empty($phone) || empty($service) || empty($date) || empty($time)) {
        $error_message = 'Please fill in all required fields.';
    } else {
        $insert_query = "INSERT INTO bookings (name, phone, email, service, preferred_date, preferred_time, notes) 
                        VALUES ('$name', '$phone', '$email', '$service', '$date', '$time', '$notes')";
        
        if ($conn->query($insert_query)) {
            $success_message = 'Your booking request has been submitted successfully! We will contact you shortly to confirm your appointment.';
            // Clear form
            $_POST = array();
        } else {
            $error_message = 'Something went wrong. Please try again or contact us directly.';
        }
    }
}

// Fetch all services for dropdown
$services_query = "SELECT s.name as service_name, c.name as category_name 
                   FROM services s 
                   JOIN categories c ON s.category_id = c.id 
                   ORDER BY c.display_order, s.name";
$services_result = $conn->query($services_query);

// Fetch promo packages for dropdown
$promos_query = "SELECT title FROM promo_packages WHERE is_active = 1 ORDER BY title";
$promos_result = $conn->query($promos_query);
?>
<?php include 'includes/header.php'; ?>

<section class="services-section">
    <div class="container">
        <div class="section-title">
            <h2>Book Your Appointment</h2>
            <p>Fill out the form below and we'll get back to you shortly</p>
        </div>

        <div class="booking-form">
            <?php if ($success_message): ?>
                <div class="success-message" data-testid="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="error-message" data-testid="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <form method="POST" action="" id="bookingForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <input type="text" id="name" name="name" required data-testid="booking-name-input">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" placeholder="09XXXXXXXXX" required data-testid="booking-phone-input">
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email Address (Optional)</label>
                    <input type="email" id="email" name="email" data-testid="booking-email-input">
                </div>

                <div class="form-group">
                    <label for="service">Desired Service *</label>
                    <select id="service" name="service" required data-testid="booking-service-select">
                        <option value="">-- Select a Service --</option>
                        
                        <optgroup label="Promo Packages">
                            <?php 
                            if ($promos_result && $promos_result->num_rows > 0):
                                while($promo = $promos_result->fetch_assoc()): 
                            ?>
                                <option value="Package: <?php echo htmlspecialchars($promo['title']); ?>">
                                    <?php echo htmlspecialchars($promo['title']); ?>
                                </option>
                            <?php 
                                endwhile;
                            endif;
                            ?>
                        </optgroup>

                        <?php 
                        $current_category = '';
                        if ($services_result && $services_result->num_rows > 0):
                            while($service = $services_result->fetch_assoc()): 
                                if ($current_category !== $service['category_name']):
                                    if ($current_category !== '') echo '</optgroup>';
                                    $current_category = $service['category_name'];
                                    echo '<optgroup label="' . htmlspecialchars($current_category) . '">';
                                endif;
                        ?>
                            <option value="<?php echo htmlspecialchars($service['service_name']); ?>">
                                <?php echo htmlspecialchars($service['service_name']); ?>
                            </option>
                        <?php 
                            endwhile;
                            if ($current_category !== '') echo '</optgroup>';
                        endif;
                        ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="date">Preferred Date *</label>
                        <input type="date" id="date" name="date" required data-testid="booking-date-input">
                    </div>
                    <div class="form-group">
                        <label for="time">Preferred Time *</label>
                        <select id="time" name="time" required data-testid="booking-time-select">
                            <option value="">-- Select Time --</option>
                            <option value="09:00">9:00 AM</option>
                            <option value="10:00">10:00 AM</option>
                            <option value="11:00">11:00 AM</option>
                            <option value="12:00">12:00 PM</option>
                            <option value="13:00">1:00 PM</option>
                            <option value="14:00">2:00 PM</option>
                            <option value="15:00">3:00 PM</option>
                            <option value="16:00">4:00 PM</option>
                            <option value="17:00">5:00 PM</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="notes">Additional Notes (Optional)</label>
                    <textarea id="notes" name="notes" placeholder="Any special requests or concerns..." data-testid="booking-notes-textarea"></textarea>
                </div>

                <button type="submit" class="btn btn-primary" data-testid="submit-booking-btn" style="width: 100%;">Submit Booking</button>
            </form>

            <div style="margin-top: 30px; text-align: center; padding: 20px; background: var(--light-gray); border-radius: 10px;">
                <p><strong>Business Hours:</strong> Everyday, 9:00 AM - 5:00 PM</p>
                <p><strong>Contact:</strong> <a href="tel:09153206502" style="color: var(--primary-pink);">09153206502</a></p>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
