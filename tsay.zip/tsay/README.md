# Tisay Aesthetics Website

A professional PHP-based website for Tisay Aesthetics beauty clinic with admin panel, booking system, and service management.

## Features

### Public Website
- **Responsive Design** - Works perfectly on mobile, tablet, and desktop
- **Hero Section** - Eye-catching landing page with clear call-to-action
- **Services Showcase** - Organized by 8 main categories:
  - Facials & Skin Treatments
  - Lashes & Brows
  - Nail Services
  - Hair Removal
  - Slimming & Body Contouring
  - Semi-Permanent Makeup (SPMU)
  - Advanced Treatments
  - Massage & Relaxation
- **Detailed Pricing Page** - Complete transparent pricing for all services
- **Special Promo Packages** - Featured bundled offers with discounted prices
- **Online Booking System** - Easy appointment booking form
- **Contact Page** - Contact form and business information

### Admin Panel
- **Dashboard** - Overview of bookings, services, and inquiries
- **Booking Management** - View, update status, and manage all bookings
- **Service Management** - Add, edit, and delete services
- **Promo Management** - Create and manage special promo packages
- **Secure Login** - Password-protected admin access

## Installation Instructions

### Prerequisites
- XAMPP (or any LAMP/WAMP stack)
- Web browser
- Text editor (optional, for customization)

### Step 1: Install XAMPP
1. Download XAMPP from: https://www.apachefriends.org/
2. Install XAMPP on your computer
3. Start Apache and MySQL services from XAMPP Control Panel

### Step 2: Set Up the Website Files
1. Copy the entire `tisay-aesthetics` folder
2. Paste it into your XAMPP `htdocs` directory:
   - Windows: `C:\xampp\htdocs\`
   - Mac: `/Applications/XAMPP/htdocs/`
   - Linux: `/opt/lampp/htdocs/`

### Step 3: Create the Database
1. Open your web browser
2. Go to: `http://localhost/phpmyadmin`
3. Click on "New" in the left sidebar
4. Create a new database named: `tisay_aesthetics`
5. Click on the database name in the left sidebar
6. Click on "Import" tab at the top
7. Click "Choose File" and select: `tisay-aesthetics/database/tisay_aesthetics.sql`
8. Click "Go" at the bottom to import

### Step 4: Configure Database Connection (If Needed)
The default configuration should work, but if you changed MySQL settings:
1. Open `tisay-aesthetics/includes/db.php`
2. Update these lines if needed:
   ```php
   define('DB_HOST', 'localhost');     // Usually 'localhost'
   define('DB_USER', 'root');          // Usually 'root'
   define('DB_PASS', '');              // Usually empty for XAMPP
   define('DB_NAME', 'tisay_aesthetics');
   ```

### Step 5: Access the Website
1. Open your web browser
2. Go to: `http://localhost/tisay-aesthetics/`
3. The website should now be live!

### Step 6: Access Admin Panel
1. Go to: `http://localhost/tisay-aesthetics/admin/login.php`
2. Default login credentials:
   - **Username:** `admin`
   - **Password:** `admin123`
3. **IMPORTANT:** Change the password after first login for security!

## Website Structure

```
tisay-aesthetics/
├── index.php              # Homepage
├── services.php           # All services overview
├── service-detail.php     # Individual service category details
├── pricing.php            # Complete price list
├── booking.php            # Booking form
├── contact.php            # Contact form
├── admin/                 # Admin panel
│   ├── login.php
│   ├── dashboard.php
│   ├── manage-bookings.php
│   ├── manage-services.php
│   ├── manage-promos.php
│   └── logout.php
├── includes/              # Reusable components
│   ├── db.php             # Database connection
│   ├── header.php         # Site header/navigation
│   └── footer.php         # Site footer
├── css/
│   └── style.css          # All styling
├── js/
│   └── main.js            # JavaScript functionality
├── images/                # Place your clinic photos here
└── database/
    └── tisay_aesthetics.sql  # Database schema
```

## Database Tables

1. **categories** - Service categories (Facials, Lashes, Nails, etc.)
2. **services** - Individual services with prices
3. **promo_packages** - Special bundled offers
4. **bookings** - Customer appointment bookings
5. **admin_users** - Admin login credentials
6. **contact_inquiries** - Messages from contact form

## Customization Guide

### Adding Your Clinic Photos
1. Place your images in the `images/` folder
2. Edit the relevant PHP files to reference your images
3. Recommended image sizes:
   - Hero section: 1920x1080px
   - Service cards: 600x400px
   - Promo banners: 1200x600px

### Changing Colors
Edit `css/style.css` and modify these CSS variables:
```css
:root {
    --primary-pink: #FFB6C1;      /* Main pink color */
    --secondary-pink: #FFC0CB;    /* Lighter pink */
    --gold: #C9A961;              /* Gold accent */
    --white: #FFFFFF;
    --text-dark: #2C2C2C;
}
```

### Changing Business Information
1. **Phone Number:** Search for `09153206502` in all files and replace
2. **Facebook Link:** Search for `TisayAesthetics` and replace with your page name
3. **Business Hours:** Edit in `includes/footer.php` and `booking.php`

### Adding/Editing Services
Use the Admin Panel:
1. Login to admin panel
2. Go to "Services" section
3. Add new services or edit existing ones
4. Changes appear immediately on the website

### Managing Promo Packages
1. Login to admin panel
2. Go to "Promos" section
3. Create new packages or edit existing ones
4. Toggle active/inactive status

## Security Recommendations

1. **Change Admin Password**
   - Login to phpMyAdmin
   - Go to `tisay_aesthetics` database
   - Click on `admin_users` table
   - Generate a new password hash using: https://bcrypt-generator.com/
   - Update the password field

2. **Restrict Admin Access**
   - Add `.htaccess` file to admin folder
   - Use IP restrictions if possible

3. **Enable HTTPS**
   - Use SSL certificate when deploying to live server
   - Update all links to use https://

4. **Regular Backups**
   - Backup database regularly from phpMyAdmin
   - Keep backup of all website files

## Troubleshooting

### Website Shows Blank Page
- Check if Apache is running in XAMPP
- Check PHP error logs in XAMPP
- Enable error display in `includes/db.php`:
  ```php
  ini_set('display_errors', 1);
  error_reporting(E_ALL);
  ```

### Database Connection Error
- Verify MySQL is running in XAMPP
- Check database credentials in `includes/db.php`
- Ensure database `tisay_aesthetics` exists

### Admin Login Not Working
- Clear browser cookies
- Verify admin_users table has the default user
- Check if sessions are enabled in PHP

### Bookings Not Saving
- Check database connection
- Verify `bookings` table exists
- Check PHP error logs

## Support & Contact

For technical support or customization requests:
- Review PHP documentation: https://www.php.net/docs.php
- XAMPP documentation: https://www.apachefriends.org/docs/
- MySQL/phpMyAdmin: https://www.phpmyadmin.net/docs/

## Browser Compatibility

- Google Chrome (Recommended)
- Mozilla Firefox
- Microsoft Edge
- Safari
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Tips

1. **Optimize Images**
   - Compress images before uploading
   - Use WebP format for better compression
   - Recommended tools: TinyPNG, Squoosh

2. **Enable Caching**
   - Add `.htaccess` rules for browser caching
   - Set appropriate cache headers

3. **Minimize CSS/JS**
   - Use minified versions for production
   - Combine files when possible

## Deployment to Live Server

1. **Export Database**
   - Go to phpMyAdmin
   - Select `tisay_aesthetics` database
   - Click Export → Go
   - Save the SQL file

2. **Upload Files**
   - Use FTP/SFTP client (FileZilla)
   - Upload all files to your web hosting
   - Maintain the same folder structure

3. **Import Database**
   - Access your hosting's phpMyAdmin
   - Create new database
   - Import the SQL file

4. **Update Configuration**
   - Edit `includes/db.php` with live server credentials
   - Update any hardcoded URLs

5. **Test Everything**
   - Test all pages
   - Submit test booking
   - Verify admin panel access
   - Check contact form

## License

This website is custom-built for Tisay Aesthetics. All rights reserved.

## Version

**Version 1.0.0** - Initial Release
- Complete website with 6 public pages
- Full admin panel with management features
- Responsive design
- Pre-populated with sample services and pricing

---

**Built with:**
- PHP 7.4+
- MySQL 5.7+
- HTML5
- CSS3
- JavaScript (ES6)
- Font Awesome Icons
- Google Fonts (Playfair Display, Inter)

**Design:**
- Color Scheme: Soft Pink + White + Gold
- Typography: Playfair Display (headings), Inter (body)
- Style: Professional, feminine, elegant, modern

---

✨ **Tisay Aesthetics - Experience a true beauty transformation with our affordable yet quality services.** ✨
