<?php
include 'includes/db.php';
$page_title = 'Our Services';

// Fetch all categories with service count
$categories_query = "SELECT c.*, COUNT(s.id) as service_count 
                     FROM categories c 
                     LEFT JOIN services s ON c.id = s.category_id 
                     GROUP BY c.id 
                     ORDER BY c.display_order ASC";
$categories_result = $conn->query($categories_query);
?>
<?php include 'includes/header.php'; ?>

<section class="services-section">
    <div class="container">
        <div class="section-title">
            <h2>All Our Services</h2>
            <p>Explore our comprehensive range of beauty and wellness treatments</p>
        </div>
        
        <div class="services-grid">
            <?php if ($categories_result && $categories_result->num_rows > 0): ?>
                <?php while($category = $categories_result->fetch_assoc()): ?>
                    <div class="service-card" data-testid="service-category-card">
                        <div class="service-icon">
                            <i class="fas <?php echo htmlspecialchars($category['icon']); ?>"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                        <p><?php echo htmlspecialchars($category['description']); ?></p>
                        <p style="color: var(--gold); font-weight: 600; margin: 10px 0;">
                            <?php echo $category['service_count']; ?> Services Available
                        </p>
                        <a href="service-detail.php?id=<?php echo $category['id']; ?>" data-testid="view-service-details-btn">
                            View All Services <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No services available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
