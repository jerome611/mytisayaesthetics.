    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>TISAY AESTHETICS</h3>
                    <p>Experience a true beauty transformation with our affordable yet quality services.</p>
                </div>
                <div class="footer-section">
                    <h4>Contact Us</h4>
                    <p><i class="fas fa-phone"></i> 09153206502</p>
                    <p><i class="fas fa-clock"></i> Everyday, 9:00 AM - 5:00 PM</p>
                    <p><i class="fab fa-facebook"></i> <a href="https://www.facebook.com/TisayAesthetics" target="_blank">Tisay Aesthetics</a></p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="pricing.php">Pricing</a></li>
                        <li><a href="booking.php">Book Now</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Tisay Aesthetics. All rights reserved.</p>
                <p><a href="admin/login.php" style="color: #fff; text-decoration: none; opacity: 0.7;">Admin</a></p>
            </div>
        </div>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>