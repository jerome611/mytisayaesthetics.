# Image Placeholder

Place your clinic photos in this folder.

## Recommended Images:

1. **Hero Section Background**
   - hero-bg.jpg (1920x1080px)
   - Should show clinic interior or happy customer

2. **Service Category Images** (600x400px each)
   - facial-treatment.jpg
   - lashes-brows.jpg
   - nail-services.jpg
   - hair-removal.jpg
   - slimming.jpg
   - spmu.jpg
   - advanced-treatments.jpg
   - massage.jpg

3. **About/Team Photos**
   - staff-photo.jpg
   - clinic-exterior.jpg
   - clinic-interior.jpg

4. **Promo Banners** (1200x600px)
   - promo-banner-1.jpg
   - promo-banner-2.jpg
   - promo-banner-3.jpg

## Image Optimization Tips:

- Use JPEG format for photos
- Use PNG for logos or graphics with transparency
- Compress images before uploading (use TinyPNG.com)
- Target file size: under 200KB for web use
- Ensure images are well-lit and professional quality

## Free Stock Photo Resources:

- Unsplash.com
- Pexels.com
- Pixabay.com

Search terms: "beauty salon", "spa treatment", "facial treatment", "beauty clinic"
