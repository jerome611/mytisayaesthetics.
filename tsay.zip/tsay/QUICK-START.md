# QUICK START GUIDE
# Tisay Aesthetics Website Setup

## 3-STEP INSTALLATION

### STEP 1: Install XAMPP
1. Download from: https://www.apachefriends.org/
2. Install on your computer
3. Open XAMPP Control Panel
4. Click "Start" for Apache
5. Click "Start" for MySQL

### STEP 2: Copy Files
1. Copy the "tisay-aesthetics" folder
2. Paste into: C:\xampp\htdocs\ (Windows)
   or /Applications/XAMPP/htdocs/ (Mac)

### STEP 3: Import Database
1. Open browser, go to: http://localhost/phpmyadmin
2. Click "New" → create database named: tisay_aesthetics
3. Click on the database
4. Click "Import" tab
5. Choose file: tisay-aesthetics/database/tisay_aesthetics.sql
6. Click "Go"

## DONE! ACCESS YOUR WEBSITE

**Public Website:**
http://localhost/tisay-aesthetics/

**Admin Panel:**
http://localhost/tisay-aesthetics/admin/login.php
- Username: admin
- Password: admin123

## COMMON ISSUES

**Issue: Blank page**
- Solution: Make sure Apache and MySQL are running in XAMPP

**Issue: Database error**
- Solution: Verify database "tisay_aesthetics" exists in phpMyAdmin

**Issue: Can't login to admin**
- Solution: Clear browser cookies and try again

## CUSTOMIZATION

**Change Colors:**
Edit: css/style.css (lines 14-21)

**Change Phone/Contact:**
Search and replace "09153206502" in all files

**Add Services:**
Use Admin Panel → Services → Add New Service

**Add Promo Packages:**
Use Admin Panel → Promos → Add New Promo

## FOLDER STRUCTURE

```
tisay-aesthetics/
├── index.php           (Homepage)
├── services.php        (Services list)
├── pricing.php         (Price list)
├── booking.php         (Booking form)
├── contact.php         (Contact form)
├── admin/              (Admin panel)
├── css/style.css       (All styles)
├── js/main.js          (JavaScript)
├── database/           (SQL file)
└── images/             (Put photos here)
```

## NEXT STEPS

1. ✅ Add your clinic photos to images/ folder
2. ✅ Change admin password for security
3. ✅ Test booking form
4. ✅ Customize colors (optional)
5. ✅ Add/edit services via admin panel
6. ✅ Set up promo packages
7. ✅ Deploy to live server when ready

## SUPPORT

For detailed instructions, see README.md
For sitemap/structure, see SITEMAP.md

---

✨ Your Tisay Aesthetics website is ready to use!
