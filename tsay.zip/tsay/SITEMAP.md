# TISAY AESTHETICS - WEBSITE SITEMAP

## PUBLIC WEBSITE PAGES

### 1. Homepage (index.php)
- Hero section with logo, tagline, and "Book Now" CTA
- Featured promo packages (3 special offers)
- Services overview grid (8 categories)
- Links to: Services, Pricing, Booking, Contact

### 2. Services Page (services.php)
- Complete list of all 8 service categories
- Service count for each category
- Links to individual service detail pages

### 3. Service Detail Pages (service-detail.php?id=X)
- Individual page for each service category:
  - Facials & Skin Treatments
  - Lashes & Brows
  - Nail Services
  - Hair Removal
  - Slimming & Body Contouring
  - Semi-Permanent Makeup (SPMU)
  - Advanced Treatments
  - Massage & Relaxation
- Complete list of services in that category with prices
- Session requirements (if applicable)
- "Book Now" button

### 4. Pricing Page (pricing.php)
- Organized pricing tables by category
- All services with descriptions and prices
- Special promo packages section
- Clear disclaimers (e.g., "Minimum 8 sessions")
- "Book Appointment" CTA

### 5. Booking Page (booking.php)
- Booking form with fields:
  - Full Name (required)
  - Phone Number (required)
  - Email Address (optional)
  - Desired Service dropdown (required)
  - Preferred Date (required)
  - Preferred Time (required)
  - Additional Notes (optional)
- Service dropdown includes:
  - Promo packages
  - All services organized by category
- Business hours and contact information
- Form validation

### 6. Contact Page (contact.php)
- Contact form:
  - Name (required)
  - Email (required)
  - Phone (optional)
  - Message (required)
- Contact information display:
  - Phone: 09153206502
  - Facebook: Tisay Aesthetics
  - Business Hours: Everyday, 9:00 AM - 5:00 PM
- Alternative contact methods section

## ADMIN PANEL PAGES

### 1. Admin Login (admin/login.php)
- Secure login form
- Username and password fields
- Default credentials: admin / admin123
- Link back to public website

### 2. Dashboard (admin/dashboard.php)
- Statistics overview:
  - Total bookings
  - Pending bookings
  - Total services
  - New inquiries
- Recent bookings table (last 10)
- Quick access to all management pages
- Navigation menu

### 3. Manage Bookings (admin/manage-bookings.php)
- Complete list of all bookings
- Columns:
  - ID
  - Customer name
  - Contact info (phone, email)
  - Service requested
  - Appointment date and time
  - Status (dropdown to update)
  - Customer notes
  - Actions (delete)
- Status options:
  - Pending (default)
  - Confirmed
  - Completed
  - Cancelled
- Real-time status updates

### 4. Manage Services (admin/manage-services.php)
- Add new service form:
  - Category selection
  - Service name
  - Description
  - Price
  - Sessions required (optional)
- List of all existing services
- Delete functionality
- Organized by category

### 5. Manage Promos (admin/manage-promos.php)
- Add new promo package form:
  - Package title
  - Description
  - Services included (separated by ' + ')
  - Original price
  - Promo price
  - Active/Inactive status
- List of all promo packages
- Toggle active/inactive status
- Delete functionality

### 6. Logout (admin/logout.php)
- Destroys admin session
- Redirects to login page

## COMMON COMPONENTS

### Header (includes/header.php)
- Logo/Brand: TISAY AESTHETICS
- Navigation menu
- Contact icons (phone + Facebook)
- Mobile responsive hamburger menu

### Footer (includes/footer.php)
- Clinic information
- Contact details
- Quick links
- Copyright notice
- Admin access link (discrete)

### Database Connection (includes/db.php)
- MySQL connection configuration
- Reused across all pages

## NAVIGATION FLOW

```
Homepage
├── Services Overview
│   └── Service Detail (each category)
│       └── Book Now
├── Pricing
│   └── Book Now
├── Book Now (direct)
└── Contact

Admin Login
└── Dashboard
    ├── Manage Bookings
    ├── Manage Services
    ├── Manage Promos
    └── Logout
```

## DATABASE STRUCTURE

### Tables:
1. **categories** (8 service categories)
2. **services** (50+ individual services)
3. **promo_packages** (special bundled offers)
4. **bookings** (customer appointments)
5. **admin_users** (admin login credentials)
6. **contact_inquiries** (contact form submissions)

## KEY FEATURES BY PAGE

### User-Facing Features:
- Responsive design (mobile, tablet, desktop)
- Professional color scheme (pink, white, gold)
- Clear pricing transparency
- Easy navigation
- Prominent CTAs (Book Now buttons)
- Contact information always visible
- Fast loading pages
- Form validation
- Success/error messages

### Admin Features:
- Secure login system
- Real-time booking management
- Status updates (pending → confirmed → completed)
- Service CRUD operations
- Promo package management
- Statistics dashboard
- Easy content management
- No coding required for updates

## TOTAL PAGE COUNT
- Public pages: 6 main pages + 8 service detail pages = 14 pages
- Admin pages: 6 pages
- **Total: 20 functional pages**

## CONTACT INFORMATION DISPLAYED
- Phone: 09153206502 (clickable tel: link)
- Facebook: Tisay Aesthetics (clickable link)
- Hours: Everyday, 9:00 AM - 5:00 PM

## BOOKING FLOW
1. User clicks "Book Now" from any page
2. Fills out booking form
3. Submits form
4. Data saved to database
5. Success message displayed
6. Admin sees booking in dashboard
7. Admin updates status as needed
8. Customer contacted via phone

---

**Note:** This sitemap represents the complete structure of the Tisay Aesthetics website as built. All pages are interconnected and fully functional.
