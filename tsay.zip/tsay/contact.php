<?php
include 'includes/db.php';
$page_title = 'Contact Us';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $message = $conn->real_escape_string(trim($_POST['message']));

    if (empty($name) || empty($email) || empty($message)) {
        $error_message = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        $insert_query = "INSERT INTO contact_inquiries (name, email, phone, message) 
                        VALUES ('$name', '$email', '$phone', '$message')";
        
        if ($conn->query($insert_query)) {
            $success_message = 'Thank you for contacting us! We will get back to you as soon as possible.';
            $_POST = array();
        } else {
            $error_message = 'Something went wrong. Please try again or contact us directly.';
        }
    }
}
?>
<?php include 'includes/header.php'; ?>

<section class="services-section">
    <div class="container">
        <div class="section-title">
            <h2>Contact Us</h2>
            <p>We'd love to hear from you</p>
        </div>

        <div class="booking-form">
            <?php if ($success_message): ?>
                <div class="success-message" data-testid="contact-success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="error-message" data-testid="contact-error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <form method="POST" action="" id="contactForm">
                <div class="form-group">
                    <label for="name">Your Name *</label>
                    <input type="text" id="name" name="name" required data-testid="contact-name-input">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required data-testid="contact-email-input">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number (Optional)</label>
                        <input type="tel" id="phone" name="phone" data-testid="contact-phone-input">
                    </div>
                </div>

                <div class="form-group">
                    <label for="message">Your Message *</label>
                    <textarea id="message" name="message" rows="6" required data-testid="contact-message-textarea"></textarea>
                </div>

                <button type="submit" class="btn btn-primary" data-testid="submit-contact-btn" style="width: 100%;">Send Message</button>
            </form>

            <div style="margin-top: 40px; text-align: center;">
                <h3 style="margin-bottom: 20px;">Other Ways to Reach Us</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px;">
                    <div style="padding: 20px; background: var(--light-gray); border-radius: 10px;">
                        <i class="fas fa-phone" style="font-size: 2rem; color: var(--gold); margin-bottom: 10px;"></i>
                        <p><strong>Phone</strong></p>
                        <a href="tel:09153206502" style="color: var(--primary-pink); text-decoration: none;">09153206502</a>
                    </div>
                    <div style="padding: 20px; background: var(--light-gray); border-radius: 10px;">
                        <i class="fab fa-facebook" style="font-size: 2rem; color: var(--gold); margin-bottom: 10px;"></i>
                        <p><strong>Facebook</strong></p>
                        <a href="https://www.facebook.com/TisayAesthetics" target="_blank" style="color: var(--primary-pink); text-decoration: none;">Tisay Aesthetics</a>
                    </div>
                    <div style="padding: 20px; background: var(--light-gray); border-radius: 10px;">
                        <i class="fas fa-clock" style="font-size: 2rem; color: var(--gold); margin-bottom: 10px;"></i>
                        <p><strong>Business Hours</strong></p>
                        <p>Everyday<br>9:00 AM - 5:00 PM</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
