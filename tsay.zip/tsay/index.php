<?php
include 'includes/db.php';
$page_title = 'Home';

// Fetch featured promo packages
$promos_query = "SELECT * FROM promo_packages WHERE is_active = 1 ORDER BY promo_price ASC LIMIT 3";
$promos_result = $conn->query($promos_query);
?>
<?php include 'includes/header.php'; ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div style="margin-bottom: 20px;">
                <img src="images/29110355-d56d-4dea-b3fa-c128273e434a.jfif" 
                     alt="Tisay Aesthetics Logo" 
                     style="max-width: 150px; height: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            </div>
            <h1>TISAY AESTHETICS</h1>
            <p class="tagline" style="font-size: 1.2rem; letter-spacing: 1px; font-weight: 500; color: var(--text-gray);">
                FACIAL · SPMU · LASHES · BROWS
            </p>
            <p class="tagline">Experience a true beauty transformation with our affordable yet quality services.</p>
            <a href="booking.php" class="btn btn-primary" data-testid="hero-book-now-btn">BOOK NOW</a>
        </div>
    </div>
</section>

<!-- Featured Promo Packages -->
<section class="promo-section">
    <div class="container">
        <div class="section-title">
            <h2>Special Promo Packages</h2>
            <p>Exclusive bundles for the ultimate beauty transformation</p>
        </div>
        <div class="promo-grid">
            <?php if ($promos_result && $promos_result->num_rows > 0): ?>
                <?php while($promo = $promos_result->fetch_assoc()): ?>
                    <div class="promo-card" data-testid="promo-card">
                        <span class="promo-badge">LIMITED OFFER</span>
                        <h3><?php echo htmlspecialchars($promo['title']); ?></h3>
                        <p><?php echo htmlspecialchars($promo['description']); ?></p>
                        <ul class="services-list">
                            <?php
                            $services = explode(' + ', $promo['services_included']);
                            foreach ($services as $service) {
                                echo '<li>' . htmlspecialchars($service) . '</li>';
                            }
                            ?>
                        </ul>
                        <div class="price-section">
                            <?php if ($promo['original_price']): ?>
                                <span class="original-price">₱<?php echo number_format($promo['original_price'], 2); ?></span>
                            <?php endif; ?>
                            <span class="promo-price">₱<?php echo number_format($promo['promo_price'], 2); ?></span>
                        </div>
                        <a href="booking.php" class="btn btn-primary">Book This Package</a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Fallback promo cards -->
                <div class="promo-card">
                    <span class="promo-badge">LIMITED OFFER</span>
                    <h3>Ultimate Beauty Package</h3>
                    <p>Complete transformation package</p>
                    <ul class="services-list">
                        <li>Basic Facial with PDT</li>
                        <li>Classic Lash Extensions</li>
                        <li>Manicure & Pedicure Regular</li>
                    </ul>
                    <div class="price-section">
                        <span class="original-price">₱1,898.00</span>
                        <span class="promo-price">₱999</span>
                    </div>
                    <a href="booking.php" class="btn btn-primary">Book This Package</a>
                </div>
                <div class="promo-card">
                    <span class="promo-badge">LIMITED OFFER</span>
                    <h3>Quick Beauty Boost</h3>
                    <p>Express beautification</p>
                    <ul class="services-list">
                        <li>Basic Facial</li>
                        <li>Lash Lifting</li>
                        <li>Manicure Regular</li>
                    </ul>
                    <div class="price-section">
                        <span class="original-price">₱1,548.00</span>
                        <span class="promo-price">₱599</span>
                    </div>
                    <a href="booking.php" class="btn btn-primary">Book This Package</a>
                </div>
                <div class="promo-card">
                    <span class="promo-badge">LIMITED OFFER</span>
                    <h3>Glow & Relax Package</h3>
                    <p>Facial and massage combo</p>
                    <ul class="services-list">
                        <li>Basic Facial</li>
                        <li>Diamond Peel</li>
                        <li>Whole Body Massage</li>
                    </ul>
                    <div class="price-section">
                        <span class="original-price">₱2,097.00</span>
                        <span class="promo-price">₱1,299</span>
                    </div>
                    <a href="booking.php" class="btn btn-primary">Book This Package</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Services Overview -->
<section class="services-section">
    <div class="container">
        <div class="section-title">
            <h2>Our Services</h2>
            <p>Comprehensive beauty and wellness treatments</p>
        </div>
        <div class="services-grid">
            <?php
            $categories_query = "SELECT * FROM categories ORDER BY display_order ASC";
            $categories_result = $conn->query($categories_query);
            
            if ($categories_result && $categories_result->num_rows > 0):
                while($category = $categories_result->fetch_assoc()):
            ?>
                <div class="service-card" data-testid="service-card">
                    <div class="service-icon">
                        <i class="fas <?php echo htmlspecialchars($category['icon']); ?>"></i>
                    </div>
                    <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                    <p><?php echo htmlspecialchars($category['description']); ?></p>
                    <a href="service-detail.php?id=<?php echo $category['id']; ?>">View Details <i class="fas fa-arrow-right"></i></a>
                </div>
            <?php
                endwhile;
            endif;
            ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>